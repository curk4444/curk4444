﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Web.Migrations
{
    /// <inheritdoc />
    public partial class AddEstadoIdToCancha : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "EstadoId",
                table: "Cancha",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Cancha_EstadoId",
                table: "Cancha",
                column: "EstadoId");

            migrationBuilder.AddForeignKey(
                name: "FK_Cancha_Estado_EstadoId",
                table: "Cancha",
                column: "EstadoId",
                principalTable: "Estado",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Cancha_Estado_EstadoId",
                table: "Cancha");

            migrationBuilder.DropIndex(
                name: "IX_Cancha_EstadoId",
                table: "Cancha");

            migrationBuilder.DropColumn(
                name: "EstadoId",
                table: "Cancha");
        }
    }
}
